pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // 如果编译时长时间卡在下载依赖（国内网络常见），
        // 把下面 google() / mavenCentral() 两行前面加 // 注释掉，
        // 再把再下面两行阿里云镜像前面的 // 去掉，保存后重新 Sync 即可。
        google()
        mavenCentral()

        // maven { url = uri("https://maven.aliyun.com/repository/google") }
        // maven { url = uri("https://maven.aliyun.com/repository/public") }
    }
}

rootProject.name = "RandomLottery"
include(":app")
