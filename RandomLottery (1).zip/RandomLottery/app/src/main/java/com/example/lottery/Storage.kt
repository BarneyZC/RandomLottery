package com.example.lottery

import android.content.Context

/** 一条中奖记录 */
data class Record(val name: String, val time: String)

/**
 * 本地存储：把名单、中奖记录、设置都存在手机/平板本机
 * 用的是系统自带的 SharedPreferences，不需要联网，也不需要任何权限
 */
class Storage(private val ctx: Context) {

    private val sp by lazy { ctx.getSharedPreferences("lottery_v1", Context.MODE_PRIVATE) }

    /** 启动时读取上次的数据；第一次运行会给出一份示例名单 */
    fun load(engine: LotteryEngine) {
        val all = LotteryEngine.parseNames(sp.getString(K_ALL, "") ?: "")
        engine.allNames.clear()
        if (all.isEmpty()) {
            engine.allNames.addAll(LotteryEngine.DEMO)
        } else {
            engine.allNames.addAll(all)
        }

        val poolRaw = sp.getString(K_POOL, null)
        val pool = if (poolRaw == null) emptyList<String>() else LotteryEngine.parseNames(poolRaw)
        engine.pool.clear()
        engine.pool.addAll(if (pool.isEmpty()) engine.allNames else pool)

        engine.history.clear()
        engine.history.addAll(readHistory())

        engine.count = sp.getInt(K_COUNT, 1)
        engine.removeOnWin = sp.getBoolean(K_REMOVE, false)
        engine.soundOn = sp.getBoolean(K_SOUND, true)
        engine.vibrateOn = sp.getBoolean(K_VIBRATE, true)
        engine.speed = sp.getInt(K_SPEED, 1)
    }

    /** 每次数据变化后调用，保存起来 */
    fun save(engine: LotteryEngine) {
        sp.edit()
            .putString(K_ALL, engine.allNames.joinToString("\n"))
            .putString(K_POOL, engine.pool.joinToString("\n"))
            .putString(K_HIS, historyToJson(engine.history))
            .putInt(K_COUNT, engine.count)
            .putBoolean(K_REMOVE, engine.removeOnWin)
            .putBoolean(K_SOUND, engine.soundOn)
            .putBoolean(K_VIBRATE, engine.vibrateOn)
            .putInt(K_SPEED, engine.speed)
            .apply()
    }

    private fun historyToJson(list: List<Record>): String {
        val arr = org.json.JSONArray()
        list.forEach { r ->
            val o = org.json.JSONObject()
            o.put("n", r.name)
            o.put("t", r.time)
            arr.put(o)
        }
        return arr.toString()
    }

    private fun readHistory(): List<Record> {
        val raw = sp.getString(K_HIS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = org.json.JSONArray(raw)
            val out = mutableListOf<Record>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Record(o.optString("n", ""), o.optString("t", "")))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val K_ALL = "all"
        private const val K_POOL = "pool"
        private const val K_HIS = "history"
        private const val K_COUNT = "count"
        private const val K_REMOVE = "remove"
        private const val K_SOUND = "sound"
        private const val K_VIBRATE = "vibrate"
        private const val K_SPEED = "speed"
    }
}
