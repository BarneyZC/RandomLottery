package com.example.lottery

/**
 * 抽奖的核心逻辑：只管数据和算法，不碰界面
 * 想改抽奖规则，改这个文件就够了
 */
class LotteryEngine {

    /** 完整名单（用于"重置奖池"时把人找回来） */
    val allNames = mutableListOf<String>()

    /** 当前奖池（开启"不重复中奖"后，中奖的人会从这里移除） */
    val pool = mutableListOf<String>()

    /** 中奖记录，最新的在最前面 */
    val history = mutableListOf<Record>()

    /** 一次抽几个人 */
    var count = 1

    /** 抽中后是否移出奖池 */
    var removeOnWin = false

    /** 是否播放音效 */
    var soundOn = true

    /** 是否震动 */
    var vibrateOn = true

    /** 滚动速度：0=慢 1=中 2=快 */
    var speed = 1

    private val speeds = longArrayOf(110L, 70L, 40L)

    /** 当前速度对应的间隔（毫秒） */
    fun speedMs(): Long = speeds[speed.coerceIn(0, 2)]

    /** 设置一次抽几人，范围 1~20 */
    fun setCount(v: Int) {
        count = v.coerceIn(1, 20)
    }

    /**
     * 从奖池里随机抽 n 个人，同一次内绝不重复
     * 用的是"洗牌后取前 n 个"，比逐个随机更公平
     */
    fun pick(n: Int): List<String> {
        if (pool.isEmpty()) return emptyList()
        val take = n.coerceIn(1, pool.size)
        return pool.shuffled().take(take)
    }

    /** 把中奖结果写进记录，并按设置决定是否移出奖池 */
    fun applyResult(picked: List<String>, time: String) {
        picked.forEach { name ->
            history.add(0, Record(name, time))
            if (removeOnWin) pool.remove(name)
        }
        // 记录最多保留 500 条，防止越攒越多
        while (history.size > 500) history.removeAt(history.size - 1)
    }

    /** 把文本框里的内容整体设为新名单 */
    fun setNames(text: String) {
        val list = parseNames(text)
        allNames.clear()
        allNames.addAll(list)
        pool.clear()
        pool.addAll(list)
    }

    /** 追加一批名字（导入文件用） */
    fun addNames(list: List<String>) {
        allNames.addAll(list)
        pool.addAll(list)
    }

    /** 把所有人放回奖池 */
    fun resetPool() {
        pool.clear()
        pool.addAll(allNames)
    }

    fun clearNames() {
        allNames.clear()
        pool.clear()
    }

    fun clearHistory() {
        history.clear()
    }

    /** 载入一份示例名单，方便第一次试用 */
    fun loadDemo() {
        clearNames()
        allNames.addAll(DEMO2)
        pool.addAll(DEMO2)
    }

    fun allNamesText(): String = allNames.joinToString("\n")

    fun poolText(): String = pool.joinToString("\n")

    /** 导出用的纯文本（名字和时间用制表符分隔，粘贴到 Excel 会自动分两列） */
    fun historyExportText(): String =
        if (history.isEmpty()) "还没有人中奖" else history.joinToString("\n") { "${it.name}\t${it.time}" }

    /** 界面上显示的记录文本 */
    fun historyDisplayText(): String =
        if (history.isEmpty()) "还没有人中奖"
        else history.joinToString("\n") { "🏅  ${it.name}      ${it.time}" }

    companion object {
        /** 第一次运行时的示例名单 */
        val DEMO = listOf("张三", "李四", "王五", "赵六", "孙七", "周八")

        /** 点"载入示例名单"时用这份 */
        val DEMO2 = listOf("张三", "李四", "王五", "赵六", "孙七", "周八", "吴九", "郑十")

        /**
         * 把一坨文本拆成名字列表
         * 支持：换行、英文逗号、中文逗号、顿号、分号、制表符、空格
         * 也就是说从 Excel 里直接复制一列粘贴进来也能识别
         */
        fun parseNames(raw: String): List<String> =
            raw.split("\n", ",", "，", "、", ";", "；", "\t", " ", "\r")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
    }
}
