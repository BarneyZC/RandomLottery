package com.example.lottery

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.TextWatcher
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 主界面：负责把 LotteryEngine 的数据显示出来，并处理点击、键盘、鼠标
 */
class MainActivity : AppCompatActivity() {

    private enum class Tab { NAMES, HISTORY, SETTINGS }

    private lateinit var storage: Storage
    private val engine = LotteryEngine()

    private val rollHandler = Handler(Looper.getMainLooper())
    private val stopHandler = Handler(Looper.getMainLooper())
    private var rolling = false      // 名字正在快速滚动
    private var stopping = false     // 正在减速定格（防止连点）
    private var tickIndex = 0

    private var tone: ToneGenerator? = null

    private var panelAlways = false  // 平板/横屏时面板常驻显示
    private var currentTab = Tab.NAMES
    private var namesDirty = false   // 文本框是否被改过（改过就不自动覆盖）

    private var pendingExportText = ""

    // ---------- 界面控件 ----------
    private lateinit var stageCard: FrameLayout
    private lateinit var tvName: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvCount: TextView
    private lateinit var btnMain: Button
    private lateinit var btnReset: Button
    private lateinit var countRow: View
    private lateinit var panelHost: View
    private lateinit var btnClosePanel: View
    private lateinit var tvPanelTitle: TextView
    private lateinit var panelNames: View
    private lateinit var panelHistory: View
    private lateinit var panelSettings: View
    private lateinit var etNames: EditText
    private lateinit var tvPoolInfo: TextView
    private lateinit var tvHistory: TextView
    private lateinit var swRemove: Switch
    private lateinit var swSound: Switch
    private lateinit var swVibrate: Switch
    private lateinit var tabNames: Button
    private lateinit var tabHistory: Button
    private lateinit var tabSettings: Button
    private lateinit var btnSpeedSlow: Button
    private lateinit var btnSpeedMid: Button
    private lateinit var btnSpeedFast: Button

    // ---------- 文件导入 / 导出 ----------
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFrom(uri)
    }

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            if (uri != null) writeTo(uri, pendingExportText)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        storage = Storage(this)
        storage.load(engine)

        bindViews()
        panelAlways = resources.getBoolean(R.bool.panel_always_visible)

        setupTabs()
        setupButtons()
        setupSwitches()
        setupMouseAndKeyboard()

        // 手机竖屏：面板默认收起；平板 / 横屏：面板常驻
        panelHost.visibility = if (panelAlways) View.VISIBLE else View.GONE
        btnClosePanel.visibility = if (panelAlways) View.GONE else View.VISIBLE

        showTab(Tab.NAMES)
        refreshStage()
        if (engine.pool.isEmpty() && engine.allNames.isEmpty()) {
            tvName.text = getString(R.string.no_names)
        }
    }

    // ==================================================================
    // 一、把 XML 里的控件和代码里的变量对上号
    // ==================================================================
    private fun bindViews() {
        stageCard = findViewById(R.id.stageCard)
        tvName = findViewById(R.id.tvName)
        tvHint = findViewById(R.id.tvHint)
        tvCount = findViewById(R.id.tvCount)
        btnMain = findViewById(R.id.btnMain)
        btnReset = findViewById(R.id.btnReset)
        countRow = findViewById(R.id.countRow)

        panelHost = findViewById(R.id.panelHost)
        btnClosePanel = findViewById(R.id.btnClosePanel)
        tvPanelTitle = findViewById(R.id.tvPanelTitle)
        panelNames = findViewById(R.id.panelNames)
        panelHistory = findViewById(R.id.panelHistory)
        panelSettings = findViewById(R.id.panelSettings)

        etNames = findViewById(R.id.etNames)
        tvPoolInfo = findViewById(R.id.tvPoolInfo)
        tvHistory = findViewById(R.id.tvHistory)

        swRemove = findViewById(R.id.swRemove)
        swSound = findViewById(R.id.swSound)
        swVibrate = findViewById(R.id.swVibrate)

        tabNames = findViewById(R.id.tabNames)
        tabHistory = findViewById(R.id.tabHistory)
        tabSettings = findViewById(R.id.tabSettings)

        btnSpeedSlow = findViewById(R.id.btnSpeedSlow)
        btnSpeedMid = findViewById(R.id.btnSpeedMid)
        btnSpeedFast = findViewById(R.id.btnSpeedFast)

        // 顶栏的齿轮按钮在部分横屏布局里不存在，用 ?. 安全调用
        findViewById<Button>(R.id.btnSettingsTop)?.setOnClickListener {
            openPanel(Tab.SETTINGS)
        }

        etNames.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                namesDirty = true
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    // ==================================================================
    // 二、三个功能按钮的切换
    // ==================================================================
    private fun setupTabs() {
        tabNames.setOnClickListener { onTabClick(Tab.NAMES) }
        tabHistory.setOnClickListener { onTabClick(Tab.HISTORY) }
        tabSettings.setOnClickListener { onTabClick(Tab.SETTINGS) }
    }

    private fun onTabClick(tab: Tab) {
        // 手机竖屏：再点一次已打开的按钮 = 收起面板
        if (!panelAlways && panelHost.visibility == View.VISIBLE && currentTab == tab) {
            closePanel()
            return
        }
        openPanel(tab)
    }

    private fun openPanel(tab: Tab) {
        panelHost.visibility = View.VISIBLE
        showTab(tab)
    }

    private fun closePanel() {
        if (!panelAlways) panelHost.visibility = View.GONE
    }

    private fun showTab(tab: Tab) {
        currentTab = tab

        panelNames.visibility = if (tab == Tab.NAMES) View.VISIBLE else View.GONE
        panelHistory.visibility = if (tab == Tab.HISTORY) View.VISIBLE else View.GONE
        panelSettings.visibility = if (tab == Tab.SETTINGS) View.VISIBLE else View.GONE

        tvPanelTitle.text = when (tab) {
            Tab.NAMES -> getString(R.string.tab_names)
            Tab.HISTORY -> getString(R.string.tab_history)
            Tab.SETTINGS -> getString(R.string.tab_settings)
        }

        // 选中的按钮用金色，没选中的用灰色
        setTabStyle(tabNames, tab == Tab.NAMES)
        setTabStyle(tabHistory, tab == Tab.HISTORY)
        setTabStyle(tabSettings, tab == Tab.SETTINGS)

        when (tab) {
            Tab.NAMES -> if (!namesDirty) etNames.setText(engine.allNamesText())
            Tab.HISTORY -> tvHistory.text = engine.historyDisplayText()
            Tab.SETTINGS -> refreshSettings()
        }
    }

    private fun setTabStyle(btn: Button, selected: Boolean) {
        btn.setBackgroundResource(
            if (selected) R.drawable.bg_btn_primary else R.drawable.bg_btn_ghost
        )
        btn.setTextColor(
            ContextCompat.getColor(
                this,
                if (selected) R.color.on_gold else R.color.text
            )
        )
    }

    // ==================================================================
    // 三、所有按钮的点击逻辑
    // ==================================================================
    private fun setupButtons() {
        btnMain.setOnClickListener { toggleRoll() }

        findViewById<Button>(R.id.btnMinus).setOnClickListener { changeCount(-1) }
        findViewById<Button>(R.id.btnPlus).setOnClickListener { changeCount(1) }

        btnReset.setOnClickListener {
            engine.resetPool()
            storage.save(engine)
            refreshStage()
            toast("${engine.pool.size} 人已回到奖池")
        }

        btnClosePanel.setOnClickListener { closePanel() }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val text = etNames.text.toString()
            engine.setNames(text)
            storage.save(engine)
            namesDirty = false
            refreshStage()
            toast("已保存 ${engine.allNames.size} 人")
        }

        findViewById<Button>(R.id.btnClearNames).setOnClickListener {
            engine.clearNames()
            storage.save(engine)
            namesDirty = false
            etNames.setText("")
            refreshStage()
            toast("名单已清空（中奖记录保留着）")
        }

        findViewById<Button>(R.id.btnImport).setOnClickListener {
            importLauncher.launch(arrayOf("text/*", "text/plain", "text/csv"))
        }

        findViewById<Button>(R.id.btnExport).setOnClickListener {
            if (engine.allNames.isEmpty()) {
                toast("名单是空的，没什么可导出")
                return@setOnClickListener
            }
            exportText(engine.allNamesText(), "名单_${fileStamp()}.txt")
        }

        findViewById<Button>(R.id.btnExportHistory).setOnClickListener {
            if (engine.history.isEmpty()) {
                toast("还没有人中奖")
                return@setOnClickListener
            }
            exportText(engine.historyExportText(), "中奖记录_${fileStamp()}.txt")
        }

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            engine.clearHistory()
            storage.save(engine)
            tvHistory.text = engine.historyDisplayText()
            toast("中奖记录已清空")
        }

        findViewById<Button>(R.id.btnDemo).setOnClickListener {
            engine.loadDemo()
            storage.save(engine)
            namesDirty = false
            etNames.setText(engine.allNamesText())
            refreshStage()
            toast("示例名单已载入")
        }

        btnSpeedSlow.setOnClickListener { setSpeed(0) }
        btnSpeedMid.setOnClickListener { setSpeed(1) }
        btnSpeedFast.setOnClickListener { setSpeed(2) }

        // 大按钮加个鼠标悬停放大效果，接鼠标时更好点
        setupHover(btnMain)
        setupHover(tabNames)
        setupHover(tabHistory)
        setupHover(tabSettings)
    }

    private fun setupSwitches() {
        swRemove.setOnCheckedChangeListener { _, checked ->
            engine.removeOnWin = checked
            storage.save(engine)
            refreshStage()
        }
        swSound.setOnCheckedChangeListener { _, checked ->
            engine.soundOn = checked
            storage.save(engine)
            if (checked) beep(40)
        }
        swVibrate.setOnCheckedChangeListener { _, checked ->
            engine.vibrateOn = checked
            storage.save(engine)
        }
    }

    private fun refreshSettings() {
        swRemove.isChecked = engine.removeOnWin
        swSound.isChecked = engine.soundOn
        swVibrate.isChecked = engine.vibrateOn
        setSpeedStyle()
    }

    private fun setSpeed(v: Int) {
        engine.speed = v
        storage.save(engine)
        setSpeedStyle()
        toast("速度：${arrayOf("慢", "中", "快")[v]}")
    }

    private fun setSpeedStyle() {
        val btns = arrayOf(btnSpeedSlow, btnSpeedMid, btnSpeedFast)
        btns.forEachIndexed { i, b ->
            val on = i == engine.speed
            b.setBackgroundResource(if (on) R.drawable.bg_btn_primary else R.drawable.bg_btn_ghost)
            b.setTextColor(ContextCompat.getColor(this, if (on) R.color.on_gold else R.color.text))
        }
    }

    // ==================================================================
    // 四、鼠标滚轮 + 键盘快捷键（接鼠标、接键盘时特别好用）
    // ==================================================================
    private fun setupMouseAndKeyboard() {
        // 鼠标滚轮停在人数那一行上下滚 = 加减人数
        setupWheel(countRow)
        // 滚轮停在舞台区也能调
        setupWheel(stageCard)
    }

    private fun setupWheel(view: View) {
        view.setOnGenericMotionListener { _, event ->
            if (event.action == MotionEvent.ACTION_SCROLL &&
                event.isFromSource(InputDevice.SOURCE_CLASS_POINTER)
            ) {
                val v = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (v != 0f) {
                    changeCount(if (v > 0) -1 else 1)
                    true
                } else false
            } else false
        }
    }

    private fun setupHover(view: View) {
        view.setOnHoverListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER ->
                    v.animate().scaleX(1.03f).scaleY(1.03f).setDuration(100).start()
                MotionEvent.ACTION_HOVER_EXIT ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false // 返回 false，让系统继续处理"悬停变色"
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // 正在输入名单时不抢键盘
        if (currentFocus is EditText) return super.onKeyDown(keyCode, event)

        when (keyCode) {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER -> {
                toggleRoll()
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS -> {
                changeCount(1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MINUS -> {
                changeCount(-1)
                return true
            }
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BACK -> {
                if (!panelAlways && panelHost.visibility == View.VISIBLE) {
                    closePanel()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun changeCount(delta: Int) {
        engine.setCount(engine.count + delta)
        tvCount.text = engine.count.toString()
        storage.save(engine)
    }

    // ==================================================================
    // 五、抽奖主流程
    // ==================================================================
    private fun toggleRoll() {
        if (stopping) return              // 减速定格中不响应
        if (rolling) stopRoll() else startRoll()
    }

    private fun startRoll() {
        if (engine.pool.isEmpty()) {
            toast(
                if (engine.removeOnWin && engine.allNames.isNotEmpty())
                    "奖池已空，点下方「重置奖池」再来一轮"
                else
                    "名单是空的，先去「名单」里添加"
            )
            return
        }
        if (engine.removeOnWin && engine.count > engine.pool.size) {
            toast("奖池只剩 ${engine.pool.size} 人了，已自动改为抽 ${engine.pool.size} 人")
            engine.setCount(engine.pool.size)
            tvCount.text = engine.count.toString()
        }

        rolling = true
        tickIndex = 0
        stageCard.setBackgroundResource(R.drawable.bg_stage)
        tvName.setTextColor(ContextCompat.getColor(this, R.color.gold))
        btnMain.text = getString(R.string.stop)
        btnMain.setBackgroundResource(R.drawable.bg_btn_ghost)
        btnMain.setTextColor(ContextCompat.getColor(this, R.color.text))
        btnMain.animate().scaleX(1f).scaleY(1f).setDuration(80).start()

        postTick()
    }

    /** 名字快速滚动，每隔 speedMs 毫秒换一个 */
    private fun postTick() {
        rollHandler.postDelayed(object : Runnable {
            override fun run() {
                if (!rolling) return
                tvName.text = engine.pool.random()
                tickIndex++
                if (tickIndex % 2 == 0) beep(20)
                postTick()
            }
        }, engine.speedMs())
    }

    /** 停止：先减速几次再定格，仪式感全在这一段 */
    private fun stopRoll() {
        rolling = false
        stopping = true
        rollHandler.removeCallbacksAndMessages(null)

        val picked = engine.pick(engine.count)
        if (picked.isEmpty()) {
            stopping = false
            return
        }

        val ms = engine.speedMs()
        val delays = longArrayOf(ms, ms * 2, 220L, 340L, 480L)
        var i = 0

        fun step() {
            if (i >= delays.size) {
                finishRoll(picked)
                return
            }
            tvName.text = picked[minOf(i, picked.lastIndex)]
            beep(30)
            val d = delays[i]
            i++
            stopHandler.postDelayed({ step() }, d)
        }
        step()
    }

    private fun finishRoll(picked: List<String>) {
        stopping = false
        val time = nowTime()
        engine.applyResult(picked, time)
        storage.save(engine)

        // 界面：金色高亮 + 名字 + 弹一下
        stageCard.setBackgroundResource(R.drawable.bg_stage_win)
        tvName.setTextColor(ContextCompat.getColor(this, R.color.gold))
        tvName.text = if (picked.size == 1) picked[0] else picked.joinToString("   ")
        btnMain.text = getString(R.string.start)
        btnMain.setBackgroundResource(R.drawable.bg_btn_primary)
        btnMain.setTextColor(ContextCompat.getColor(this, R.color.on_gold))

        stageCard.animate().scaleX(1.05f).scaleY(1.05f).setDuration(120).withEndAction {
            stageCard.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        }.start()

        winSound()
        vibrate(70)

        refreshStage()
        tvHint.text = "🎉 恭喜 ${picked.size} 位 · 奖池剩 ${engine.pool.size} 人"
        if (currentTab == Tab.NAMES && !namesDirty && panelHost.visibility == View.VISIBLE) {
            etNames.setText(engine.allNamesText())
        }
        if (currentTab == Tab.HISTORY) tvHistory.text = engine.historyDisplayText()
    }

    private fun refreshStage() {
        tvCount.text = engine.count.toString()
        val pool = engine.pool.size
        if (!rolling && !stopping) {
            tvHint.text = if (engine.removeOnWin) "奖池 $pool 人 · 不重复模式" else "奖池 $pool 人"
        }
        tvPoolInfo.text = "奖池 $pool 人 · 完整名单 ${engine.allNames.size} 人"
        btnReset.visibility =
            if (engine.removeOnWin && pool == 0 && engine.allNames.isNotEmpty()) View.VISIBLE
            else View.GONE
    }

    // ==================================================================
    // 六、文件的导入 / 导出
    // ==================================================================
    private fun importFrom(uri: Uri) {
        val text = readText(uri)
        val list = LotteryEngine.parseNames(text)
        if (list.isEmpty()) {
            toast("文件里没识别到名字")
            return
        }
        engine.addNames(list)
        storage.save(engine)
        namesDirty = false
        etNames.setText(engine.allNamesText())
        refreshStage()
        toast("已导入 ${list.size} 人，现在共 ${engine.allNames.size} 人")
    }

    /** 读文本，UTF-8 读出来是乱码时自动改用 GBK（Windows 记事本默认存 GBK） */
    private fun readText(uri: Uri): String {
        return try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return ""
            val utf8 = String(bytes, Charsets.UTF_8)
            if (utf8.contains('\uFFFD')) {
                try {
                    String(bytes, Charset.forName("GBK"))
                } catch (e: Exception) {
                    utf8
                }
            } else utf8
        } catch (e: Exception) {
            toast("读取失败：${e.message}")
            ""
        }
    }

    private fun exportText(text: String, fileName: String) {
        pendingExportText = text
        try {
            exportLauncher.launch(fileName)
        } catch (e: Exception) {
            toast("无法打开文件管理器")
        }
    }

    private fun writeTo(uri: Uri, text: String) {
        try {
            contentResolver.openOutputStream(uri)?.use {
                it.write(text.toByteArray(Charsets.UTF_8))
            }
            toast("已导出完成")
        } catch (e: Exception) {
            toast("导出失败：${e.message}")
        }
    }

    // ==================================================================
    // 七、音效、震动、提示
    // ==================================================================
    private fun beep(durationMs: Int) {
        if (!engine.soundOn) return
        if (tone == null) {
            tone = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 50)
            } catch (e: Exception) {
                null
            }
        }
        try {
            tone?.startTone(ToneGenerator.TONE_CDMA_PIP, durationMs)
        } catch (e: Exception) {
            // 某些设备没有音频输出，忽略即可
        }
    }

    private fun winSound() {
        if (!engine.soundOn) return
        try {
            tone?.startTone(ToneGenerator.TONE_CDMA_PIP, 150)
            stopHandler.postDelayed({
                tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 220)
            }, 170)
        } catch (e: Exception) {
            // 忽略
        }
    }

    private fun vibrate(ms: Long) {
        if (!engine.vibrateOn) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(VibratorManager::class.java)
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (e: Exception) {
            // 平板没有马达，忽略
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun nowTime(): String =
        SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date())

    private fun fileStamp(): String =
        SimpleDateFormat("MMdd_HHmm", Locale.getDefault()).format(Date())

    override fun onDestroy() {
        rollHandler.removeCallbacksAndMessages(null)
        stopHandler.removeCallbacksAndMessages(null)
        tone?.release()
        tone = null
        super.onDestroy()
    }
}
