# 本软件不混淆代码，保持默认即可
# 如果你以后要发布到应用商店，再按需添加规则
-keep class com.example.lottery.** { *; }
